import json
import logging
import numpy as np
import pandas as pd
from numpy.linalg import inv

logger = logging.getLogger(__name__)

class BlackLittermanModel:
    """
    提供给 OpenClaw/WorkBuddy 的 Black-Litterman 投资组合优化模型 (Python Muscle)。
    这是量化策略师与宏观分析师结合的最佳工具：将大模型产生的主观观点 (Views) 与市场均衡先验 (Market Equilibrium) 相结合，
    生成后验预期收益率和最优配置权重。
    """
    
    @staticmethod
    def optimize_portfolio(returns_json: str, market_caps: dict, views: list, tau: float = 0.05, risk_aversion: float = 2.5) -> str:
        """
        计算 Black-Litterman 后验预期收益与权重。
        :param returns_json: 资产历史日收益率数据
        :param market_caps: 各资产的市场流通市值权重字典，如 {"SPY": 0.5, "TLT": 0.3, "GLD": 0.2}
        :param views: 观点列表。绝对观点: {"type": "absolute", "asset": "SPY", "return": 0.08, "confidence": 0.5}
                      相对观点: {"type": "relative", "asset_long": "GLD", "asset_short": "TLT", "spread": 0.03, "confidence": 0.4}
        :param tau: 标量，反映对先验估计的不确定性（通常在 0.01 到 0.05 之间）
        :param risk_aversion: 市场风险厌恶系数 (通常为 2.0 到 3.0)
        :return: JSON 包含后验预期收益率和优化后的权重
        """
        try:
            parsed = json.loads(returns_json)
            if parsed.get("status") != "success":
                return json.dumps({"status": "error", "message": "Invalid input returns data"})
                
            data = parsed["data"]
            df = pd.DataFrame(data)
            tickers = list(df.columns)
            N = len(tickers)
            
            if len(market_caps) != N:
                return json.dumps({"status": "error", "message": "Market caps must cover all assets in the returns data."})
                
            # 1. 计算协方差矩阵 (年化)
            cov_matrix = df.cov() * 252
            
            # 2. 计算市场均衡权重 (W_mkt)
            total_cap = sum(market_caps[t] for t in tickers)
            W_mkt = np.array([market_caps[t] / total_cap for t in tickers])
            
            # 3. 计算先验市场均衡预期收益率 (Pi)
            # Pi = risk_aversion * cov_matrix * W_mkt
            Pi = risk_aversion * cov_matrix.dot(W_mkt)
            
            # 4. 构建观点矩阵 (P, Q) 和 误差矩阵 (Omega)
            K = len(views)
            if K == 0:
                # 如果没有任何主观观点，直接返回市场均衡权重
                return json.dumps({
                    "status": "success",
                    "message": "No views provided, returning market equilibrium",
                    "posterior_returns": {tickers[i]: round(float(Pi[i]), 4) for i in range(N)},
                    "optimal_weights": {tickers[i]: round(float(W_mkt[i]), 4) for i in range(N)}
                })
                
            P = np.zeros((K, N))
            Q = np.zeros(K)
            confidences = np.zeros(K)
            
            for i, view in enumerate(views):
                if view["type"] == "absolute":
                    idx = tickers.index(view["asset"])
                    P[i, idx] = 1.0
                    Q[i] = view["return"]
                elif view["type"] == "relative":
                    idx_long = tickers.index(view["asset_long"])
                    idx_short = tickers.index(view["asset_short"])
                    P[i, idx_long] = 1.0
                    P[i, idx_short] = -1.0
                    Q[i] = view["spread"]
                confidences[i] = view.get("confidence", 0.5)
                
            # 构建 Omega (对角阵，基于先验方差和置信度)
            # 简化处理：Omega = diag(P * (tau * cov_matrix) * P^T) / confidence
            # 置信度越高，方差越小
            omega_diags = np.diag(P.dot(tau * cov_matrix).dot(P.T))
            # 避免除以 0
            confidences = np.clip(confidences, 0.01, 0.99)
            Omega = np.diag(omega_diags * (1 - confidences) / confidences)
            
            # 5. 计算后验预期收益率 (Posterior Expected Returns)
            # ER = [(tau * cov)^-1 + P^T * Omega^-1 * P]^-1 * [(tau * cov)^-1 * Pi + P^T * Omega^-1 * Q]
            tau_cov_inv = inv(tau * cov_matrix)
            Omega_inv = inv(Omega)
            
            term1 = inv(tau_cov_inv + P.T.dot(Omega_inv).dot(P))
            term2 = tau_cov_inv.dot(Pi) + P.T.dot(Omega_inv).dot(Q)
            
            posterior_ER = term1.dot(term2)
            
            # 6. 计算后验协方差矩阵
            posterior_cov = cov_matrix + term1
            
            # 7. 计算基于后验预期收益的无约束最优权重
            # W_opt = (risk_aversion * posterior_cov)^-1 * posterior_ER
            W_opt = inv(risk_aversion * posterior_cov).dot(posterior_ER)
            
            # 归一化权重 (假设不加杠杆，满仓)
            W_opt_normalized = W_opt / np.sum(np.abs(W_opt))
            
            return json.dumps({
                "status": "success",
                "prior_equilibrium_returns": {tickers[i]: round(float(Pi[i]), 4) for i in range(N)},
                "posterior_expected_returns": {tickers[i]: round(float(posterior_ER[i]), 4) for i in range(N)},
                "optimal_weights": {tickers[i]: round(float(W_opt_normalized[i]), 4) for i in range(N)}
            })
            
        except Exception as e:
            logger.error(f"Failed to calculate Black-Litterman model: {e}")
            return json.dumps({"status": "error", "message": str(e)})

