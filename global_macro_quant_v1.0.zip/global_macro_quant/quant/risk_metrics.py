import json
import logging
import numpy as np
import scipy.stats as stats
import pandas as pd

logger = logging.getLogger(__name__)

class InstitutionalRiskManager:
    """
    提供给 OpenClaw/WorkBuddy 的机构级风控引擎 (Python Muscle)。
    计算各类专业的尾部风险指标，如 VaR 和 CVaR。
    由首席风控官在平台中调用。
    """
    
    @staticmethod
    def calculate_var_cvar(returns_json: str, weights: dict, confidence_level: float = 0.95) -> str:
        """
        使用历史模拟法 (Historical Simulation) 计算投资组合的 Value at Risk (VaR) 和 Expected Shortfall (CVaR)。
        :param returns_json: 资产历史日收益率 JSON
        :param weights: 各资产权重字典，如 {"SPY": 0.4, "TLT": 0.6}
        :param confidence_level: 置信水平 (通常为 0.95 或 0.99)
        :return: JSON 包含单日/月度/年度的 VaR 和 CVaR
        """
        try:
            parsed = json.loads(returns_json)
            if parsed.get("status") != "success":
                return json.dumps({"status": "error", "message": "Invalid input returns data"})
                
            data = parsed["data"]
            df = pd.DataFrame(data)
            
            # 计算投资组合历史每日收益序列
            portfolio_returns = np.zeros(len(df))
            for ticker, weight in weights.items():
                if ticker in df.columns:
                    portfolio_returns += df[ticker].values * weight
                else:
                    return json.dumps({"status": "error", "message": f"Ticker {ticker} not found in returns data."})
            
            # 1. 历史模拟法 VaR
            # 找到对应置信水平下的分位数
            var_1d = np.percentile(portfolio_returns, (1 - confidence_level) * 100)
            
            # 2. CVaR (Expected Shortfall)
            # 计算那些比 VaR 更糟糕的日子里的平均损失
            cvar_1d = portfolio_returns[portfolio_returns <= var_1d].mean()
            
            # 3. 转换为更长周期的风险 (平方根法则，假设收益独立同分布)
            # 10日 (约两周) 和 21日 (约一月) 的 VaR
            var_10d = var_1d * np.sqrt(10)
            cvar_10d = cvar_1d * np.sqrt(10)
            
            var_21d = var_1d * np.sqrt(21)
            cvar_21d = cvar_1d * np.sqrt(21)
            
            # 计算年化波动率和夏普比率(粗略估计)作为参考
            annual_vol = portfolio_returns.std() * np.sqrt(252)
            annual_ret = portfolio_returns.mean() * 252
            sharpe = annual_ret / annual_vol if annual_vol > 0 else 0
            
            return json.dumps({
                "status": "success",
                "confidence_level": confidence_level,
                "metrics": {
                    "annualized_return": round(float(annual_ret), 4),
                    "annualized_volatility": round(float(annual_vol), 4),
                    "sharpe_ratio_est": round(float(sharpe), 4),
                },
                "tail_risk": {
                    "daily_var": round(float(var_1d), 4),
                    "daily_cvar": round(float(cvar_1d), 4),
                    "10_day_var": round(float(var_10d), 4),
                    "10_day_cvar": round(float(cvar_10d), 4),
                    "monthly_var": round(float(var_21d), 4),
                    "monthly_cvar": round(float(cvar_21d), 4)
                }
            })
            
        except Exception as e:
            logger.error(f"Failed to calculate VaR/CVaR: {e}")
            return json.dumps({"status": "error", "message": str(e)})

class KellyCriterionEngine:
    """
    提供给 OpenClaw/WorkBuddy 的凯利公式头寸管理引擎。
    """
    
    @staticmethod
    def calculate_kelly_fraction(win_rate: float, avg_win_pct: float, avg_loss_pct: float, kelly_multiplier: float = 0.5) -> str:
        """
        基于历史胜率和盈亏比计算最优投注比例 (Kelly Fraction)。
        :param win_rate: 策略历史胜率 (如 0.55 表示 55%)
        :param avg_win_pct: 历史平均盈利幅度 (如 0.05 表示 5%)
        :param avg_loss_pct: 历史平均亏损幅度绝对值 (如 0.03 表示 3%)
        :param kelly_multiplier: 凯利乘数 (如 0.5 即半凯利，用于平滑波动)
        :return: JSON 包含建议的仓位占比
        """
        try:
            if win_rate < 0 or win_rate > 1:
                return json.dumps({"status": "error", "message": "win_rate must be between 0 and 1"})
            if avg_loss_pct <= 0:
                return json.dumps({"status": "error", "message": "avg_loss_pct must be greater than 0 (absolute value)"})
                
            loss_rate = 1 - win_rate
            payoff_ratio = avg_win_pct / avg_loss_pct
            
            # 基础凯利公式：f* = W - (L / R)
            # W: 胜率, L: 败率, R: 盈亏比
            full_kelly = win_rate - (loss_rate / payoff_ratio)
            
            # 如果期望收益为负，凯利公式会得出负值，此时不应建仓
            if full_kelly <= 0:
                recommended_fraction = 0.0
                advice = "DO NOT TRADE. Negative expected value."
            else:
                recommended_fraction = full_kelly * kelly_multiplier
                advice = "TRADE ALLOWED."
                
            # 仓位上限硬控 (一般不超过 100%)
            recommended_fraction = min(recommended_fraction, 1.0)
            
            return json.dumps({
                "status": "success",
                "inputs": {
                    "win_rate": win_rate,
                    "payoff_ratio": round(payoff_ratio, 2)
                },
                "kelly_fractions": {
                    "full_kelly": round(full_kelly, 4) if full_kelly > 0 else 0.0,
                    "multiplier_applied": kelly_multiplier,
                    "recommended_position_size": round(recommended_fraction, 4)
                },
                "advice": advice
            })
            
        except Exception as e:
            logger.error(f"Failed to calculate Kelly fraction: {e}")
            return json.dumps({"status": "error", "message": str(e)})

