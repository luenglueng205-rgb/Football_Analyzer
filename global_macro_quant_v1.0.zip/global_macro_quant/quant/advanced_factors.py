import json
import logging
import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)

class MomentumReversalEngine:
    """
    提供给 OpenClaw/WorkBuddy 的动量反转因子计算引擎。
    由量化策略师在平台中调用。
    """
    
    @staticmethod
    def calculate_factors(prices_json: str, short_window: int = 20, long_window: int = 126) -> str:
        """
        计算时间序列动量（长周期）和均值反转（短周期）因子。
        :param prices_json: fetch_historical_prices 返回的价格 JSON
        :param short_window: 短期反转窗口（默认 20 个交易日，约 1 个月）
        :param long_window: 长期动量窗口（默认 126 个交易日，约半年）
        :return: JSON 包含各资产的动量、反转因子得分及综合交易信号
        """
        try:
            parsed = json.loads(prices_json)
            if parsed.get("status") != "success":
                return json.dumps({"status": "error", "message": "Invalid input price data"})
                
            data = parsed["data"]
            result = {}
            
            for ticker, prices in data.items():
                s = pd.Series(prices)
                s.index = pd.to_datetime(s.index)
                s = s.sort_index()
                
                if len(s) < long_window:
                    result[ticker] = {"error": "Not enough data points"}
                    continue
                    
                current_price = s.iloc[-1]
                
                # 1. 计算长期动量因子 (Time-Series Momentum)
                # 逻辑：价格显著高于半年前，趋势向上
                price_long_ago = s.iloc[-long_window]
                momentum_score = (current_price / price_long_ago) - 1
                
                # 2. 计算短期反转因子 (Mean Reversion)
                # 逻辑：价格偏离近一个月均值过远，随时可能回调（Z-score 形式）
                short_prices = s.iloc[-short_window:]
                short_mean = short_prices.mean()
                short_std = short_prices.std()
                # 价格过高则反转分为负，价格过低则反转分为正
                reversal_score = -((current_price - short_mean) / short_std)
                
                # 3. 综合评估信号
                # 寻找“大趋势向上，但短期回调（超卖）”的机会 -> 强烈做多
                # 寻找“大趋势向下，但短期反弹（超买）”的机会 -> 强烈做空
                signal = "NEUTRAL"
                if momentum_score > 0.05 and reversal_score > 1.0:
                    signal = "STRONG_BUY (Uptrend + Short-term Oversold)"
                elif momentum_score < -0.05 and reversal_score < -1.0:
                    signal = "STRONG_SELL (Downtrend + Short-term Overbought)"
                elif momentum_score > 0.1:
                    signal = "BUY (Trend Following)"
                elif momentum_score < -0.1:
                    signal = "SELL (Trend Following)"
                    
                result[ticker] = {
                    "momentum_score": round(float(momentum_score), 4),
                    "reversal_score": round(float(reversal_score), 4),
                    "signal": signal
                }
                
            return json.dumps({
                "status": "success",
                "short_window": short_window,
                "long_window": long_window,
                "factors": result
            })
            
        except Exception as e:
            logger.error(f"Failed to calculate momentum reversal factors: {e}")
            return json.dumps({"status": "error", "message": str(e)})

class VolatilityFactorEngine:
    """
    提供给 OpenClaw/WorkBuddy 的波动率因子计算引擎。
    由量化策略师在平台中调用。
    """
    
    @staticmethod
    def calculate_volatility_skew(prices_json: str, window: int = 63) -> str:
        """
        计算波动率偏度（Volatility Skew）和已实现波动率。
        :param prices_json: fetch_historical_prices 返回的价格 JSON
        :param window: 波动率计算窗口（默认 63 个交易日，约 3 个月）
        :return: JSON 包含年化波动率和上下行波动率偏度
        """
        try:
            parsed = json.loads(prices_json)
            if parsed.get("status") != "success":
                return json.dumps({"status": "error", "message": "Invalid input price data"})
                
            data = parsed["data"]
            result = {}
            
            for ticker, prices in data.items():
                s = pd.Series(prices)
                s.index = pd.to_datetime(s.index)
                s = s.sort_index()
                
                if len(s) < window + 1:
                    result[ticker] = {"error": "Not enough data points"}
                    continue
                    
                # 计算日收益率
                returns = s.pct_change().dropna().iloc[-window:]
                
                # 1. 整体年化波动率 (假设每年 252 个交易日)
                annual_volatility = returns.std() * np.sqrt(252)
                
                # 2. 计算上行和下行波动率 (区分上涨日的波动和下跌日的波动)
                positive_returns = returns[returns > 0]
                negative_returns = returns[returns < 0]
                
                up_vol = positive_returns.std() * np.sqrt(252) if len(positive_returns) > 0 else 0
                down_vol = negative_returns.std() * np.sqrt(252) if len(negative_returns) > 0 else 0
                
                # 3. 波动率偏度 (Downside Volatility vs Upside Volatility)
                # 偏度 > 1 意味着下跌时的波动远大于上涨时的波动（恐慌特征）
                vol_skew = down_vol / up_vol if up_vol > 0 else float('inf')
                
                signal = "NORMAL"
                if vol_skew > 1.5:
                    signal = "HIGH_PANIC (Downside risk dominates)"
                elif vol_skew < 0.7:
                    signal = "HIGH_GREED (Upside speculation dominates)"
                    
                result[ticker] = {
                    "annualized_volatility": round(float(annual_volatility), 4),
                    "upside_volatility": round(float(up_vol), 4),
                    "downside_volatility": round(float(down_vol), 4),
                    "volatility_skew": round(float(vol_skew), 4),
                    "regime": signal
                }
                
            return json.dumps({
                "status": "success",
                "window": window,
                "volatility_metrics": result
            })
            
        except Exception as e:
            logger.error(f"Failed to calculate volatility metrics: {e}")
            return json.dumps({"status": "error", "message": str(e)})
