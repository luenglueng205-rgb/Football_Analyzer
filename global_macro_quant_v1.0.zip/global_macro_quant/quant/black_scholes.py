import json
import logging
import numpy as np
from scipy.stats import norm

logger = logging.getLogger(__name__)

class BlackScholesPricer:
    """
    提供给 OpenClaw/WorkBuddy 的期权定价引擎 (Python Muscle)。
    基于 Black-Scholes-Merton (BSM) 模型，专门用于评估资产的期权理论价格以及隐含波动率(Implied Volatility)和希腊字母(Greeks)。
    由量化策略师或风控官在平台中调用。
    """
    
    @staticmethod
    def calculate_bsm_greeks(S: float, K: float, T: float, r: float, sigma: float, option_type: str = "call") -> str:
        """
        计算期权理论价格及希腊字母。
        :param S: 标的资产当前价格 (Spot Price)
        :param K: 期权执行价格 (Strike Price)
        :param T: 到期时间 (以年为单位，如 3个月 = 0.25)
        :param r: 无风险利率 (如 5% = 0.05)
        :param sigma: 标的资产年化波动率 (如 20% = 0.20)
        :param option_type: 期权类型，"call" (看涨) 或 "put" (看跌)
        :return: JSON 格式的期权价格和 Greeks
        """
        try:
            if T <= 0 or sigma <= 0:
                return json.dumps({"status": "error", "message": "Time to maturity (T) and Volatility (sigma) must be > 0"})
                
            # 计算 d1 和 d2
            d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
            d2 = d1 - sigma * np.sqrt(T)
            
            # 正态分布的累积分布函数 (CDF) 和概率密度函数 (PDF)
            N_d1 = norm.cdf(d1)
            N_d2 = norm.cdf(d2)
            n_d1 = norm.pdf(d1)
            
            # 价格计算
            if option_type.lower() == "call":
                price = S * N_d1 - K * np.exp(-r * T) * N_d2
                delta = N_d1
                theta = -(S * n_d1 * sigma) / (2 * np.sqrt(T)) - r * K * np.exp(-r * T) * N_d2
                rho = theta / 365  # 每日时间损耗
            elif option_type.lower() == "put":
                price = K * np.exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)
                delta = N_d1 - 1
                theta = -(S * n_d1 * sigma) / (2 * np.sqrt(T)) + r * K * np.exp(-r * T) * norm.cdf(-d2)
                rho = theta / 365
            else:
                return json.dumps({"status": "error", "message": "option_type must be 'call' or 'put'"})
                
            # Gamma 和 Vega 对 Call 和 Put 是相同的
            gamma = n_d1 / (S * sigma * np.sqrt(T))
            vega = S * np.sqrt(T) * n_d1 / 100  # 波动率变化 1% 的价格影响
            
            result = {
                "status": "success",
                "parameters": {
                    "spot_price": S,
                    "strike_price": K,
                    "time_to_maturity_years": T,
                    "risk_free_rate": r,
                    "volatility": sigma,
                    "option_type": option_type.lower()
                },
                "pricing": {
                    "theoretical_price": round(price, 4)
                },
                "greeks": {
                    "delta": round(delta, 4),   # 对标的价格变化的敏感度
                    "gamma": round(gamma, 4),   # Delta 的敏感度（凸性）
                    "theta": round(theta, 4),   # 时间损耗（年化）
                    "rho_daily": round(rho, 4), # 每日时间损耗
                    "vega": round(vega, 4)      # 对波动率变化的敏感度
                }
            }
            
            return json.dumps(result)
            
        except Exception as e:
            logger.error(f"Failed to calculate BSM pricing: {e}")
            return json.dumps({"status": "error", "message": str(e)})
