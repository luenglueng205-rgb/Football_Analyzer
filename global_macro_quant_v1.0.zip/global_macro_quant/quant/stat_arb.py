import json
import logging
import pandas as pd
import numpy as np

try:
    from statsmodels.tsa.stattools import coint
except ImportError:
    coint = None

logger = logging.getLogger(__name__)

class StatisticalArbitrageEngine:
    """
    提供给 OpenClaw/WorkBuddy 的纯统计套利引擎 (Python Muscle)。
    由量化策略师在平台中调用。
    """
    
    @staticmethod
    def calculate_stat_arb_signals(prices_json: str, pair: list, z_score_threshold: float = 2.0) -> str:
        """
        利用协整分析和Z-score计算指定资产对的统计套利信号。
        :param prices_json: fetch_historical_prices 提取的价格 JSON
        :param pair: 包含两个资产 Ticker 的列表，例如 ["GLD", "SLV"]
        :param z_score_threshold: 触发交易的 Z-score 阈值（默认 2.0，即均值回归触发线）
        :return: JSON 包含协整检验 p-value、当前 Z-score 以及多空交易信号
        """
        if coint is None:
            return json.dumps({"status": "error", "message": "Module 'statsmodels' not installed. Required for cointegration test."})
            
        try:
            parsed = json.loads(prices_json)
            if parsed.get("status") != "success":
                return json.dumps({"status": "error", "message": "Invalid input price data"})
            
            data = parsed["data"]
            if len(pair) != 2 or pair[0] not in data or pair[1] not in data:
                return json.dumps({"status": "error", "message": "Pair tickers not found in price data"})
                
            # 将 JSON 数据转回 pandas Series，并对齐索引
            s1 = pd.Series(data[pair[0]])
            s2 = pd.Series(data[pair[1]])
            
            df = pd.concat([s1, s2], axis=1, join='inner').dropna()
            df.columns = [pair[0], pair[1]]
            
            if len(df) < 50:
                return json.dumps({"status": "error", "message": "Not enough overlapping data points for cointegration test."})
                
            # 1. 协整性检验 (Engle-Granger)
            y0 = df[pair[0]]
            y1 = df[pair[1]]
            score, p_value, _ = coint(y0, y1)
            
            # 2. 计算价差和 Z-score
            # 简单起见，使用OLS回归系数或直接价格差（假设同量级或已对数化）。
            # 这里采用基础的比例价差：Spread = P1 - beta * P2
            beta = np.cov(y0, y1)[0, 1] / np.var(y1)
            spread = y0 - beta * y1
            
            mean_spread = spread.mean()
            std_spread = spread.std()
            current_spread = spread.iloc[-1]
            
            current_z_score = (current_spread - mean_spread) / std_spread
            
            # 3. 生成交易信号
            signal = "NEUTRAL"
            if current_z_score > z_score_threshold:
                # 价差过大：做空 P1，做多 P2
                signal = f"SHORT_{pair[0]}_LONG_{pair[1]}"
            elif current_z_score < -z_score_threshold:
                # 价差过小：做多 P1，做空 P2
                signal = f"LONG_{pair[0]}_SHORT_{pair[1]}"
                
            result = {
                "status": "success",
                "pair": pair,
                "cointegration_p_value": round(p_value, 4),
                "is_cointegrated": bool(p_value < 0.05),
                "current_z_score": round(current_z_score, 2),
                "z_score_threshold": z_score_threshold,
                "trading_signal": signal
            }
            
            return json.dumps(result)
            
        except Exception as e:
            logger.error(f"Failed to calculate stat arb signals: {e}")
            return json.dumps({"status": "error", "message": str(e)})

