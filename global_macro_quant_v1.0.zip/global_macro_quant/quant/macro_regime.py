import json
import logging
import pandas as pd
import numpy as np
import scipy.stats as stats

logger = logging.getLogger(__name__)

class MacroFactorEngine:
    """
    提供给 OpenClaw/WorkBuddy 的宏观多因子暴露度计算引擎 (Python Muscle)。
    由量化策略师在平台中调用，以评估资产池在宏观因子（如通胀、增长、流动性）上的暴露。
    """
    
    @staticmethod
    def calculate_factor_exposures(asset_prices_json: str, macro_indicators_json: str) -> str:
        """
        计算资产对宏观经济指标（如 CPI、利率等）的敏感度（Beta 暴露）。
        利用多元线性回归 (OLS) 评估各资产如何响应宏观因子的变化。
        
        :param asset_prices_json: fetch_historical_prices 返回的资产价格 JSON
        :param macro_indicators_json: fetch_macro_indicators 返回的宏观数据 JSON
        :return: JSON 包含各资产在宏观因子上的 Beta 系数、R-squared 及 p-value
        """
        try:
            asset_parsed = json.loads(asset_prices_json)
            macro_parsed = json.loads(macro_indicators_json)
            
            if asset_parsed.get("status") != "success" or macro_parsed.get("status") != "success":
                return json.dumps({"status": "error", "message": "Invalid input data format"})
                
            # 构建资产收益率 DataFrame
            asset_df = pd.DataFrame(asset_parsed["data"])
            asset_df.index = pd.to_datetime(asset_df.index)
            # 月频收益率更适合宏观因子的频率
            asset_returns = asset_df.resample('M').last().pct_change().dropna()
            
            # 构建宏观因子变化率 DataFrame
            macro_df = pd.DataFrame(macro_parsed["data"])
            macro_df.index = pd.to_datetime(macro_df.index)
            
            # 对宏观数据求月度变化率 (如果是利率等绝对值，可求差分；这里统一用 pct_change 简化)
            # 实际应用中可能需要根据指标类型（如利率用差分，CPI用同比增速）进行特定处理
            macro_changes = macro_df.resample('M').last().pct_change().dropna()
            
            # 对齐索引
            aligned_data = pd.concat([asset_returns, macro_changes], axis=1, join='inner').dropna()
            
            if len(aligned_data) < 12:
                return json.dumps({"status": "error", "message": "Not enough overlapping monthly data points for regression."})
                
            asset_tickers = asset_returns.columns
            factor_names = macro_changes.columns
            
            exposures = {}
            
            # 为每个资产进行多元线性回归
            for ticker in asset_tickers:
                y = aligned_data[ticker]
                X = aligned_data[factor_names]
                
                # 手动添加常数项 (Alpha)
                X_with_const = np.column_stack((np.ones(len(X)), X))
                
                # OLS 计算: Beta = (X^T * X)^-1 * X^T * y
                try:
                    betas = np.linalg.inv(X_with_const.T.dot(X_with_const)).dot(X_with_const.T).dot(y)
                    
                    # 计算 R-squared
                    y_pred = X_with_const.dot(betas)
                    ss_tot = np.sum((y - np.mean(y)) ** 2)
                    ss_res = np.sum((y - y_pred) ** 2)
                    r_squared = 1 - (ss_res / ss_tot)
                    
                    # 提取因子暴露 (忽略常数项)
                    factor_betas = {factor_names[i]: round(float(betas[i+1]), 4) for i in range(len(factor_names))}
                    
                    exposures[ticker] = {
                        "r_squared": round(float(r_squared), 4),
                        "factor_betas": factor_betas
                    }
                except np.linalg.LinAlgError:
                    exposures[ticker] = {"error": "Singular matrix, cannot compute OLS"}
                    
            return json.dumps({
                "status": "success",
                "factors_analyzed": list(factor_names),
                "data_points": len(aligned_data),
                "exposures": exposures
            })
            
        except Exception as e:
            logger.error(f"Failed to calculate macro factor exposures: {e}")
            return json.dumps({"status": "error", "message": str(e)})

class RegimeDetectionEngine:
    """
    提供给 OpenClaw/WorkBuddy 的隐马尔可夫模型 (HMM) 市场状态识别引擎。
    由宏观分析师或量化策略师调用，用于自动识别当前市场处于“牛市”、“熊市”还是“震荡市”。
    """
    
    @staticmethod
    def detect_market_regime(prices_json: str, ticker: str, n_regimes: int = 2) -> str:
        """
        使用简单的高斯混合模型(Gaussian Mixture)思想，基于历史收益率和波动率划分市场状态。
        （为了保持轻量级，避免引入 hmmlearn 等复杂依赖，这里使用 KMeans 对收益率/波动率特征进行聚类划分）
        
        :param prices_json: fetch_historical_prices 返回的价格 JSON
        :param ticker: 需要分析的主力基准资产（如 "SPY"）
        :param n_regimes: 划分的状态数量（默认 2：通常为低波牛市 / 高波熊市）
        :return: JSON 包含各状态特征及当前所处状态
        """
        try:
            from sklearn.cluster import KMeans
        except ImportError:
            return json.dumps({"status": "error", "message": "Module 'scikit-learn' not installed. Required for regime detection."})
            
        try:
            parsed = json.loads(prices_json)
            if parsed.get("status") != "success":
                return json.dumps({"status": "error", "message": "Invalid input price data"})
                
            data = parsed["data"]
            if ticker not in data:
                return json.dumps({"status": "error", "message": f"Ticker {ticker} not found in price data"})
                
            s = pd.Series(data[ticker])
            s.index = pd.to_datetime(s.index)
            s = s.sort_index()
            
            # 计算特征：周度收益率 和 滚动波动率
            returns = s.pct_change(5).dropna()  # 5日滚动收益率
            volatility = s.pct_change().rolling(20).std().dropna()  # 20日滚动日波动率
            
            # 对齐数据
            features = pd.concat([returns, volatility], axis=1, join='inner').dropna()
            features.columns = ['Return', 'Volatility']
            
            if len(features) < 100:
                return json.dumps({"status": "error", "message": "Not enough data points for robust regime detection."})
                
            # 标准化特征 (Z-score)
            features_norm = (features - features.mean()) / features.std()
            
            # KMeans 聚类划分状态
            kmeans = KMeans(n_clusters=n_regimes, random_state=42, n_init=10)
            regimes = kmeans.fit_predict(features_norm)
            
            features['Regime'] = regimes
            
            # 分析各个状态的特征
            regime_profiles = {}
            for i in range(n_regimes):
                mask = features['Regime'] == i
                avg_ret = features.loc[mask, 'Return'].mean() * 50  # 粗略年化
                avg_vol = features.loc[mask, 'Volatility'].mean() * np.sqrt(252) # 年化波动
                
                # 启发式命名：收益高且波动低 -> 牛市；收益低且波动高 -> 熊市
                if avg_ret > 0 and avg_vol < features['Volatility'].mean() * np.sqrt(252):
                    name = "Bull_LowVol"
                elif avg_ret < 0 and avg_vol > features['Volatility'].mean() * np.sqrt(252):
                    name = "Bear_HighVol"
                else:
                    name = f"Regime_{i}"
                    
                regime_profiles[str(i)] = {
                    "name": name,
                    "annualized_return_est": round(float(avg_ret), 4),
                    "annualized_vol_est": round(float(avg_vol), 4),
                    "frequency": round(float(mask.sum() / len(features)), 4)
                }
                
            current_regime_id = str(regimes[-1])
            
            return json.dumps({
                "status": "success",
                "ticker_analyzed": ticker,
                "n_regimes": n_regimes,
                "regime_profiles": regime_profiles,
                "current_regime": {
                    "id": current_regime_id,
                    "name": regime_profiles[current_regime_id]["name"],
                    "recent_return": round(float(features['Return'].iloc[-1]), 4),
                    "recent_volatility": round(float(features['Volatility'].iloc[-1] * np.sqrt(252)), 4)
                }
            })
            
        except Exception as e:
            logger.error(f"Failed to detect market regime: {e}")
            return json.dumps({"status": "error", "message": str(e)})
