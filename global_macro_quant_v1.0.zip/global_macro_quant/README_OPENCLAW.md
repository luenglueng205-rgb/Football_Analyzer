# OpenClaw Native Deep Adaptation Guide

本模块已深度适配 OpenClaw 2026.04.11 及更高版本的 Native Multi-Agent Workspace 标准。

## 架构说明
传统的 Python 量化脚本通常需要自己编写复杂的 LLM 调度代码，而我们利用了 OpenClaw 的 **Execution Adapter** 机制，将底层模型 (Python Muscle) 和大脑 (LLM Brain) 完全解耦。

### 1. `openclaw.json`
我们在 `configs/openclaw.json` 中定义了四个原生的 Sub-Agent (首席基金经理、宏观分析师、量化策略师、首席风控官)，并为它们绑定了沙箱隔离和工具权限。

### 2. `openclaw_adapter.py`
这是大模型与 Python 引擎通信的“桥梁”。
OpenClaw 在调用工具时，不再需要启动重量级的 HTTP Server，而是直接通过命令行 CLI 的方式执行：
```bash
python openclaw_adapter.py --tool fetch_historical_prices --kwargs '{"tickers": ["SPY"]}'
```
脚本会自动解析 JSON 参数，路由给 `DataFetcher` 等类，然后将计算结果（动量、夏普比率、凯利公式建议等）打印到 `stdout`，供大模型读取并进行下一步决策。

## 部署方法
1. 将 `global_macro_quant` 文件夹打包为 `.zip`。
2. 登录 OpenClaw Workspace 平台，选择 **"Import Native Workspace"**。
3. 平台会自动读取 `configs/openclaw.json`，并为你生成 4 个相互协作的 AI 量化团队。
