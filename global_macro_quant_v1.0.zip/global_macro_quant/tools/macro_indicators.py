import json
import logging
import pandas_datareader.data as web
import datetime

logger = logging.getLogger(__name__)

class MacroIndicatorFetcher:
    """
    提供给 OpenClaw/WorkBuddy 的纯宏观数据抓取工具 (Python Muscle)。
    由宏观分析师 Agent 在平台中调用，以获取定性分析的硬数据支撑。
    """
    
    @staticmethod
    def fetch_macro_indicators(indicators: list, start_date: str = None, end_date: str = None) -> str:
        """
        从美联储经济数据库 (FRED) 获取宏观经济指标。
        :param indicators: 指标代码列表。例如：['FEDFUNDS'] (联邦基金利率), ['CPIAUCSL'] (核心CPI)
        :param start_date: 起始日期 (YYYY-MM-DD)，默认获取近2年
        :param end_date: 结束日期 (YYYY-MM-DD)，默认获取至今
        :return: JSON 格式的日期和宏观指标数据
        """
        logger.info(f"Fetching macro indicators {indicators} from FRED...")
        try:
            if not end_date:
                end_date = datetime.date.today().strftime('%Y-%m-%d')
            if not start_date:
                start_date = (datetime.date.today() - datetime.timedelta(days=730)).strftime('%Y-%m-%d')
                
            data = web.DataReader(indicators, 'fred', start_date, end_date)
            data.dropna(inplace=True)
            
            result = {}
            for col in data.columns:
                # 日期转换为字符串
                result[col] = {str(k.date()): float(v) for k, v in data[col].items()}
                
            return json.dumps({"status": "success", "data": result})
        except Exception as e:
            logger.error(f"Failed to fetch macro indicators: {e}")
            return json.dumps({"status": "error", "message": str(e)})

