import json
import logging
from typing import Dict, List
import yfinance as yf
import pandas as pd

logger = logging.getLogger(__name__)

class DataFetcher:
    """
    提供给 OpenClaw/WorkBuddy 的纯数据抓取工具 (Python Muscle)。
    由宏观分析师或量化策略师在平台中调用。
    """
    
    @staticmethod
    def fetch_historical_prices(tickers: List[str], period: str = "1y", interval: str = "1d") -> str:
        """
        获取多资产的历史收盘价。
        :param tickers: 资产代码列表，如 ["SPY", "GLD", "TLT", "BTC-USD"]
        :param period: 时间跨度，如 "1mo", "1y", "5y"
        :param interval: K线级别，如 "1d", "1wk"
        :return: JSON 格式的日期和价格数据
        """
        logger.info(f"Fetching {period} historical prices for {tickers}...")
        try:
            data = yf.download(tickers, period=period, interval=interval, group_by='ticker', progress=False)
            
            result = {}
            if len(tickers) == 1:
                ticker = tickers[0]
                df = data['Close'].dropna()
                result[ticker] = {str(k.date()): float(v) for k, v in df.items()}
            else:
                for ticker in tickers:
                    df = data[ticker]['Close'].dropna()
                    result[ticker] = {str(k.date()): float(v) for k, v in df.items()}
            
            return json.dumps({"status": "success", "data": result})
        except Exception as e:
            logger.error(f"Failed to fetch data: {e}")
            return json.dumps({"status": "error", "message": str(e)})

    @staticmethod
    def calculate_momentum_factors(price_json: str, lookback_days: int = 126) -> str:
        """
        根据获取的价格数据计算动量因子。
        :param price_json: `fetch_historical_prices` 返回的 JSON 数据
        :param lookback_days: 动量回溯天数 (默认126天，约半年)
        :return: 各资产的动量因子得分 JSON
        """
        try:
            parsed = json.loads(price_json)
            if parsed.get("status") != "success":
                return json.dumps({"status": "error", "message": "Invalid input price data"})
                
            data = parsed["data"]
            momentum_scores = {}
            
            for ticker, prices in data.items():
                # 转换回 pandas Series
                s = pd.Series(prices)
                s.index = pd.to_datetime(s.index)
                s = s.sort_index()
                
                if len(s) >= lookback_days:
                    # 计算动量: (Current / Past) - 1
                    current_price = s.iloc[-1]
                    past_price = s.iloc[-lookback_days]
                    momentum = (current_price / past_price) - 1
                    momentum_scores[ticker] = round(momentum, 4)
                else:
                    momentum_scores[ticker] = None
                    
            return json.dumps({
                "status": "success", 
                "lookback_days": lookback_days,
                "momentum_scores": momentum_scores
            })
        except Exception as e:
            return json.dumps({"status": "error", "message": str(e)})
