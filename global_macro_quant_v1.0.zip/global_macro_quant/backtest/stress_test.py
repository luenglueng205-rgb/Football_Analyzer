import json
import logging
import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)

class BlackSwanStressTester:
    """
    提供给 OpenClaw/WorkBuddy 的黑天鹅压力测试引擎 (Python Muscle)。
    由首席风控官在平台中调用，以评估在历史极端事件中投资组合的最大回撤。
    """
    
    @staticmethod
    def run_stress_test(returns_json: str, weights: dict, scenario: str = "2008_crisis") -> str:
        """
        运行指定历史冲击场景的压力测试。
        :param returns_json: 包含资产日收益率的 JSON 数据
        :param weights: 各资产权重字典，如 {"SPY": 0.4, "GLD": 0.4, "TLT": 0.2}
        :param scenario: 黑天鹅场景，支持 "2008_crisis" (次贷危机), "2020_covid" (新冠熔断)
        :return: JSON 包含组合在此场景下的预期收益与最大回撤
        """
        scenarios = {
            "2008_crisis": ("2008-09-01", "2008-11-30"),
            "2020_covid": ("2020-02-20", "2020-03-23")
        }
        
        if scenario not in scenarios:
            return json.dumps({"status": "error", "message": f"Unknown scenario: {scenario}"})
            
        start_date, end_date = scenarios[scenario]
        
        try:
            parsed = json.loads(returns_json)
            if parsed.get("status") != "success":
                return json.dumps({"status": "error", "message": "Invalid input returns data"})
                
            data = parsed["data"]
            # 过滤指定日期的数据
            df = pd.DataFrame(data)
            df.index = pd.to_datetime(df.index)
            
            mask = (df.index >= start_date) & (df.index <= end_date)
            stress_period_df = df.loc[mask]
            
            if len(stress_period_df) == 0:
                return json.dumps({"status": "error", "message": "No data available for the specified stress scenario dates."})
                
            # 计算加权组合收益
            portfolio_returns = np.zeros(len(stress_period_df))
            
            for ticker, weight in weights.items():
                if ticker in stress_period_df.columns:
                    portfolio_returns += stress_period_df[ticker].values * weight
                else:
                    return json.dumps({"status": "error", "message": f"Ticker {ticker} not found in returns data."})
            
            # 计算总收益和最大回撤
            cum_returns = (1 + portfolio_returns).cumprod()
            total_return = cum_returns[-1] - 1
            
            running_max = np.maximum.accumulate(cum_returns)
            drawdown = (cum_returns - running_max) / running_max
            max_drawdown = drawdown.min()
            
            result = {
                "status": "success",
                "scenario": scenario,
                "start_date": start_date,
                "end_date": end_date,
                "stress_total_return": round(total_return, 4),
                "stress_max_drawdown": round(max_drawdown, 4),
                "is_survived": bool(max_drawdown > -0.20)  # 回撤没超过 20% 算活下来
            }
            
            return json.dumps(result)
            
        except Exception as e:
            logger.error(f"Failed to run stress test: {e}")
            return json.dumps({"status": "error", "message": str(e)})

