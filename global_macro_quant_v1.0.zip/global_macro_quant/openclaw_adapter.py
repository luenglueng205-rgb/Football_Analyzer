import argparse
import json
import sys

# Import all quantitative tools from the system
from quant.advanced_factors import MomentumReversalEngine, VolatilityFactorEngine
from quant.black_litterman import BlackLittermanModel
from quant.black_scholes import BlackScholesPricer
from quant.macro_regime import MacroFactorEngine, RegimeDetectionEngine
from quant.options_and_macro_parity import OptionsImpliedVolatilityEngine, MacroRiskParityV2
from quant.risk_metrics import InstitutionalRiskManager, KellyCriterionEngine
from quant.risk_parity import RiskParityEngine
from quant.stat_arb import StatisticalArbitrageEngine
from backtest.stress_test import BlackSwanStressTester
from tools.data_fetcher import DataFetcher
from tools.macro_indicators import MacroIndicatorFetcher
from skills.discovery import DiscoveryEngine

def main():
    """
    OpenClaw Native Tool Adapter
    This script acts as the entry point for the OpenClaw platform to execute the Python quant tools.
    """
    parser = argparse.ArgumentParser(description="OpenClaw Native Tool Adapter for Global Macro Quant")
    parser.add_argument("--tool", type=str, required=True, help="Tool name to execute (e.g., fetch_historical_prices)")
    parser.add_argument("--kwargs", type=str, required=True, help="JSON string containing the arguments for the tool")
    
    args = parser.parse_args()
    tool_name = args.tool
    
    try:
        kwargs = json.loads(args.kwargs)
    except Exception as e:
        print(json.dumps({"status": "error", "message": f"Failed to parse kwargs JSON: {e}"}))
        sys.exit(1)
        
    # Map tool names to their corresponding static methods
    dispatch_map = {
        "fetch_historical_prices": DataFetcher.fetch_historical_prices,
        "calculate_momentum_factors": DataFetcher.calculate_momentum_factors,
        "fetch_macro_indicators": MacroIndicatorFetcher.fetch_macro_indicators,
        "calculate_stat_arb_signals": StatisticalArbitrageEngine.calculate_stat_arb_signals,
        "calculate_bsm_greeks": BlackScholesPricer.calculate_bsm_greeks,
        "calculate_momentum_reversal_factors": MomentumReversalEngine.calculate_factors,
        "calculate_volatility_factors": VolatilityFactorEngine.calculate_volatility_skew,
        "calculate_factor_exposures": MacroFactorEngine.calculate_factor_exposures,
        "detect_market_regime": RegimeDetectionEngine.detect_market_regime,
        "optimize_portfolio_black_litterman": BlackLittermanModel.optimize_portfolio,
        "calculate_var_cvar": InstitutionalRiskManager.calculate_var_cvar,
        "calculate_kelly_fraction": KellyCriterionEngine.calculate_kelly_fraction,
        "calculate_implied_volatility": OptionsImpliedVolatilityEngine.calculate_implied_volatility,
        "calculate_factor_risk_parity": MacroRiskParityV2.calculate_factor_risk_parity,
        "run_stress_test": BlackSwanStressTester.run_stress_test,
        "discover_and_learn_skill": DiscoveryEngine.discover_and_learn_skill
        # Note: calculate_risk_parity_weights and run_portfolio_backtest might require instance initialization
        # For full native support, these should also be wrapped in static methods or instantiated here.
    }
    
    if tool_name not in dispatch_map:
        print(json.dumps({"status": "error", "message": f"Tool '{tool_name}' is not supported by this adapter."}))
        sys.exit(1)
        
    try:
        func = dispatch_map[tool_name]
        result = func(**kwargs)
        print(result)
    except Exception as e:
        print(json.dumps({"status": "error", "message": f"Execution error: {str(e)}"}))
        sys.exit(1)

if __name__ == "__main__":
    main()
